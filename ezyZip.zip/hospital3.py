import socket
import pandas as pd
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import SimpleRNN, Dense
import streamlit as st

import matplotlib.pyplot as plt

def train_Rnn(X_train, y_train):
    rnn_model = Sequential([
        SimpleRNN(64, input_shape=(X_train.shape[1], 1)),
        Dense(64, activation='relu'),
        Dense(1, activation='sigmoid')
    ])
    rnn_model.compile(optimizer='adam',
                      loss='binary_crossentropy',
                      metrics=['accuracy'])

    epochs = 10
    accuracy_list = []
    loss_list = []
    for epoch in range(epochs):
        st.text(f"Epoch {epoch+1}/{epochs}")
        history = rnn_model.fit(X_train, y_train, epochs=1, batch_size=32, verbose=1)
        train_loss = history.history['loss'][0]
        train_accuracy = history.history['accuracy'][0]
        st.text(f"Training Loss: {train_loss}, Accuracy: {train_accuracy}")
        accuracy_list.append(train_accuracy)
        loss_list.append(train_loss)

    st.write("Training completed! RNN Model Weights successfully Transferred to global model")



    # Display training accuracy and loss graphs
    plt.plot(range(1, epochs+1), accuracy_list, marker='o', label='Accuracy')
    plt.plot(range(1, epochs+1), loss_list, marker='o', label='Loss')
    plt.xlabel('Epoch')
    plt.title('Training Accuracy and Loss')
    plt.legend()
    st.pyplot(plt)

    return rnn_model


def main():
        st.set_page_config(page_title="Hospital 3", layout="wide")

        # Read dataset
        dataset = pd.read_csv("hospital_data/hospital3.csv")

        # Encode categorical variables
        encoder = LabelEncoder()
        dataset['gender'] = encoder.fit_transform(dataset['gender'])
        dataset['smoking_history'] = encoder.fit_transform(dataset['smoking_history'])

        # Split features and target
        X = dataset.drop(columns=['diabetes']).values
        y = dataset['diabetes'].values.reshape(-1, 1)

        # Split data for training
        X_train, _, y_train, _ = train_test_split(X, y, test_size=0.2, random_state=42)

        # Reshape X_train for SimpleRNN input
        X_train = X_train.reshape((X_train.shape[0], X_train.shape[1], 1))

        st.markdown("# APOLLO HOSPITAL")

        st.image("Images/apollo.png")

        st.title("Running the RNN model in APOLLO HOSPITAL local system ")

        # Train SimpleRNN model
        rnn_model = train_Rnn(X_train, y_train)

        # Save model weights in HDF5 format
        rnn_model.save_weights("Rnn_model.weights.h5")

        # Connect to server and send model weights
        client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        client_socket.connect(('localhost', 1111))
        with open("Rnn_model.weights.h5", "rb") as f:
            model_weights_data = f.read()
        client_socket.send(model_weights_data)
        client_socket.close()
        st.write("Hospital 3 RNN Model weights sent successfully!")


if __name__ == "__main__":
    main()
