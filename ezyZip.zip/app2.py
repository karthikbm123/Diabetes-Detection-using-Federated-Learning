import streamlit as st
import subprocess


def run_script(script_name):
    subprocess.Popen(["python", f"{script_name}.py"])


def main():
    st.set_page_config(page_title="Global Server Model", layout="wide")
    # Set the title of the app
    st.title("SECURE FEDERATED LEARNING FOR DECENTRALIZED AI SYSTEMS")
    st.image('Images/coverpage.png',use_column_width=True)

    if st.button("Start Global Server Model", key="start_global"):
        subprocess.Popen(["streamlit", "run", "globalmodel.py"])

    st.title("Fetch Data from Hospitals")

    if st.button("Fetch Data from Hospital 1", key="fetch_hospital_1"):
        subprocess.Popen(["streamlit", "run", "hospital1.py"])

    if st.button("Fetch Data from Hospital 2", key="fetch_hospital_2"):
        subprocess.Popen(["streamlit", "run", "hospital2.py"])

    if st.button("Fetch Data from Hospital 3", key="fetch_hospital_3"):
        subprocess.Popen(["streamlit", "run", "hospital3.py"])


    st.header("Federated Learning Details")
    st.title("Federated Learning: Decentralized AI Training")
    st.write("""
        Federated Learning represents a pioneering approach to training machine learning models across multiple decentralized edge devices or servers while ensuring data privacy and security. Traditional machine learning methods often rely on centralizing data in a single location, raising concerns about privacy, security, and regulatory compliance. In contrast, Federated Learning operates on a decentralized paradigm, allowing models to be trained locally on the devices where data resides, without the need to transfer raw data to a central server.
        """)

    st.subheader("Key Features and Benefits:")
    st.markdown("""
        - **Privacy Preservation:** Federated Learning enables the training of AI models without the need to share raw data. Instead, only model updates, such as gradients, are transmitted between devices and the central server, preserving the privacy of sensitive information.
        - **Data Security:** By keeping data localized and avoiding centralized storage, Federated Learning reduces the risk of data breaches and unauthorized access. This decentralized approach enhances data security and compliance with stringent regulations such as GDPR, HIPAA, and CCPA.
        - **Edge Computing Integration:** Federated Learning seamlessly integrates with edge computing environments, leveraging the computational power of edge devices to perform model training locally. This reduces latency, enhances scalability, and optimizes resource utilization.
        - **Collaborative Learning:** Federated Learning fosters collaboration among distributed entities, allowing organizations to collectively improve AI models while maintaining control over proprietary data. This collaborative framework encourages knowledge sharing and innovation across diverse domains and stakeholders.
        - **Adaptive Model Updates:** By aggregating local model updates at the central server, Federated Learning facilitates the continuous improvement of AI models over time. This iterative learning process enables models to adapt to evolving data distributions and user preferences without compromising privacy or security.
        - **Regulatory Compliance:** Federated Learning addresses regulatory challenges associated with data privacy and protection by minimizing data exposure and ensuring compliance with data governance standards. Organizations can leverage Federated Learning to unlock the value of their data assets while adhering to regulatory requirements.
        """)

    st.subheader("Applications:")
    st.markdown("""
        Federated Learning has diverse applications across industries, including healthcare, finance, telecommunications, and IoT. Some notable use cases include:
        - **Healthcare:** Federated Learning enables collaborative model training on sensitive patient data distributed across healthcare institutions, facilitating the development of personalized medical diagnostics and treatment recommendations while safeguarding patient privacy.
        - **Finance:** Financial institutions leverage Federated Learning to analyze transaction data, detect fraudulent activities, and enhance customer risk profiling without compromising the confidentiality of financial records.
        - **Telecommunications:** Federated Learning empowers telecom companies to optimize network performance, predict user behavior, and deliver personalized services based on subscriber data while respecting user privacy preferences.
        - **IoT and Smart Devices:** Federated Learning enables smart devices, such as smartphones, wearables, and smart home appliances, to learn user preferences, adapt to individual behaviors, and deliver personalized experiences without transmitting sensitive data to external servers.
        """)

    st.subheader("Conclusion:")
    st.write("""
        Federated Learning represents a transformative paradigm shift in AI training, offering a principled approach to decentralized model development while upholding data privacy, security, and regulatory compliance. By embracing Federated Learning, organizations can harness the collective intelligence of distributed data sources to drive innovation, empower collaboration, and unlock the full potential of AI in a privacy-preserving manner.
        """)


if __name__ == "__main__":
    main()
