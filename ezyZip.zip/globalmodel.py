import socket
import streamlit as st
import pandas as pd
from predict import load_model, predict

# Load the trained model
model = load_model("ANN_model.weights.h5")

class GloablModelReceiver:
    def __init__(self, host='localhost', port=1111, num_hospitals=3):
        self.host = host
        self.port = port
        self.num_hospitals = num_hospitals

    def receive_weights(self, client_socket, hospital_name):
        # Receive model weights from client
        received_data = b''
        while True:
            chunk = client_socket.recv(1024)
            if not chunk:
                break
            received_data += chunk

        # Save received weights
        filename = f"{hospital_name}_received.weights.h5"
        with open(filename, "wb") as f:
            f.write(received_data)

        st.write(f"Model weights from {hospital_name} received successfully!")

    def start_server(self):
        try:
            # Create socket
            server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            server_socket.bind((self.host, self.port))
            server_socket.listen(5)

            # Accept connections from clients
            st.markdown("# GLOBAL AGGREGATOR MODEL")
            st.image("Images/ai_server_02.png")
            st.title("Waiting for clients...")


            # Counter for tracking hospitals
            hospital_count = 0

            while hospital_count < self.num_hospitals:
                client_socket, addr = server_socket.accept()
                hospital_count += 1
                st.write(f"Connection from {addr} established for Hospital {hospital_count}.")

                # Receive and save weights for the current hospital
                self.receive_weights(client_socket, f"Hospital_{hospital_count}")

                client_socket.close()

            server_socket.close()
            st.write("All model weights received successfully!")

        except Exception as e:
            st.write("An error occurred:", e)


# Load the trained model

def main():
    model_receiver = GloablModelReceiver()
    model_receiver.start_server()

    st.title("Diabetes Prediction App")
    st.markdown("Model Performance")
    st.image("Images/Figure_1.png")


    # Create input fields for user to enter data
    st.subheader("Enter Patient Details:")
    gender = st.radio("Gender", ["Male", "Female"])
    age = st.number_input("Age", min_value=0, max_value=100, step=1)
    hypertension = st.selectbox("Hypertension", [0, 1])
    heart_disease = st.selectbox("Heart Disease", [0, 1])
    smoking_history = st.selectbox("Smoking History", ["Unknown", "Never", "Formerly", "Currently"])
    bmi = st.number_input("BMI", min_value=0.0, max_value=100.0, step=0.1)
    hba1c_level = st.number_input("HbA1c Level", min_value=0.0, max_value=15.0, step=0.1)
    blood_glucose_level = st.number_input("Blood Glucose Level", min_value=0, max_value=500, step=1)

    # Map categorical values to numeric codes
    smoking_history_mapping = {"Unknown": 0, "Never": 1, "Formerly": 2, "Currently": 3}
    gender_mapping = {"Male": 0, "Female": 1}
    smoking_history = smoking_history_mapping[smoking_history]
    gender = gender_mapping[gender]

    # Prepare input data as a DataFrame
    input_data = pd.DataFrame({
        "gender": [gender],
        "age": [age],
        "hypertension": [hypertension],
        "heart_disease": [heart_disease],
        "smoking_history": [smoking_history],
        "bmi": [bmi],
        "HbA1c_level": [hba1c_level],
        "blood_glucose_level": [blood_glucose_level]
    })

    # Make prediction
    if st.button("Predict"):
        # Make prediction using the loaded model
        prediction = predict(model, input_data)

        # Display prediction result
        if prediction[0] == 1:
            st.error("The patient is predicted to have diabetes.")
        else:
            st.success("The patient is predicted not to have diabetes.")

if __name__ == "__main__":
    main()


# import socket
# import streamlit as st
# import pandas as pd
# from predict import load_model, predict
#
# # Load the trained model
# model = load_model("Rnn_model.weights.h5")
#
# class GloablModelReceiver:
#     def __init__(self, host='localhost', port=1111, num_hospitals=3):
#         self.host = host
#         self.port = port
#         self.num_hospitals = num_hospitals
#         self.weights_received = False
#
#     def receive_weights(self, client_socket, hospital_name):
#         # Receive model weights from client
#         received_data = b''
#         while True:
#             chunk = client_socket.recv(1024)
#             if not chunk:
#                 break
#             received_data += chunk
#
#         # Save received weights
#         filename = f"{hospital_name}_received.weights.h5"
#         with open(filename, "wb") as f:
#             f.write(received_data)
#
#         st.write(f"Model weights from {hospital_name} received successfully!")
#         self.weights_received = True
#
#     def start_server(self):
#         try:
#             # Create socket
#             server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
#             server_socket.bind((self.host, self.port))
#             server_socket.listen(5)
#
#             # Accept connections from clients
#
#             st.markdown("# GLOBAL AGGREGATOR MODEL")
#             st.image("Images/ai_server_02.png")
#             st.title("Waiting for clients...")
#
#             # Counter for tracking hospitals
#             hospital_count = 0
#
#             while hospital_count < self.num_hospitals:
#                 client_socket, addr = server_socket.accept()
#                 hospital_count += 1
#                 st.write(f"Connection from {addr} established for Hospital {hospital_count}.")
#
#                 # Receive and save weights for the current hospital
#                 self.receive_weights(client_socket, f"Hospital_{hospital_count}")
#
#                 client_socket.close()
#
#             server_socket.close()
#             self.display_prediction_form()  # Display prediction form after weights received
#
#         except Exception as e:
#             st.write("An error occurred:", e)
#
#     def display_prediction_form(self):
#         st.title("Diabetes Prediction App")
#         # Create input fields for user to enter data
#         st.subheader("Enter Patient Details:")
#         gender = st.radio("Gender", ["Male", "Female"])
#         age = st.number_input("Age", min_value=0, max_value=100, step=1)
#         hypertension = st.selectbox("Hypertension", [0, 1])
#         heart_disease = st.selectbox("Heart Disease", [0, 1])
#         smoking_history = st.selectbox("Smoking History", ["Unknown", "Never", "Formerly", "Currently"])
#         bmi = st.number_input("BMI", min_value=0.0, max_value=100.0, step=0.1)
#         hba1c_level = st.number_input("HbA1c Level", min_value=0.0, max_value=15.0, step=0.1)
#         blood_glucose_level = st.number_input("Blood Glucose Level", min_value=0, max_value=500, step=1)
#
#         # Map categorical values to numeric codes
#         smoking_history_mapping = {"Unknown": 0, "Never": 1, "Formerly": 2, "Currently": 3}
#         gender_mapping = {"Male": 0, "Female": 1}
#         smoking_history = smoking_history_mapping[smoking_history]
#         gender = gender_mapping[gender]
#
#         # Prepare input data as a DataFrame
#         input_data = pd.DataFrame({
#             "gender": [gender],
#             "age": [age],
#             "hypertension": [hypertension],
#             "heart_disease": [heart_disease],
#             "smoking_history": [smoking_history],
#             "bmi": [bmi],
#             "HbA1c_level": [hba1c_level],
#             "blood_glucose_level": [blood_glucose_level]
#         })
#
#         # Make prediction
#         if st.button("Predict"):
#             # Make prediction using the loaded model
#             prediction = predict(model, input_data)
#
#             # Display prediction result
#             if prediction[0] == 1:
#                 st.error("The patient is predicted to have diabetes.")
#             else:
#                 st.success("The patient is predicted not to have diabetes.")
#
# def main():
#     model_receiver = GloablModelReceiver()
#     model_receiver.start_server()
#
# if __name__ == "__main__":
#     main()
