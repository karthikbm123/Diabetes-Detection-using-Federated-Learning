import socket
import pandas as pd
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense
import streamlit as st

import matplotlib.pyplot as plt

def train_ann(X_train, y_train):
    ann_model = Sequential([
        Dense(64, activation='relu', input_shape=(X_train.shape[1],)),
        Dense(64, activation='relu'),
        Dense(1, activation='sigmoid')
    ])
    ann_model.compile(optimizer='adam',
                      loss='binary_crossentropy',
                      metrics=['accuracy'])

    epochs = 10
    accuracy_list = []
    loss_list = []
    for epoch in range(epochs):
        st.text(f"Epoch {epoch+1}/{epochs}")
        history = ann_model.fit(X_train, y_train, epochs=1, batch_size=32, verbose=1)
        train_loss = history.history['loss'][0]
        train_accuracy = history.history['accuracy'][0]
        st.text(f"Training Loss: {train_loss}, Accuracy: {train_accuracy}")
        accuracy_list.append(train_accuracy)
        loss_list.append(train_loss)

    st.write("Training completed! ANN Model Weights successfully Transferred to global model")

    # Display training accuracy and loss graphs
    plt.plot(range(1, epochs+1), accuracy_list, marker='o', label='Accuracy')
    plt.plot(range(1, epochs+1), loss_list, marker='o', label='Loss')
    plt.xlabel('Epoch')
    plt.title('Training Accuracy and Loss')
    plt.legend()
    st.pyplot(plt)

    return ann_model


def main():
    st.set_page_config(page_title="Hospital 1", layout="wide")
    try:
        # Read dataset
        dataset = pd.read_csv("hospital_data/hospital1.csv")

        # Encode categorical variables
        encoder = LabelEncoder()
        dataset['gender'] = encoder.fit_transform(dataset['gender'])
        dataset['smoking_history'] = encoder.fit_transform(dataset['smoking_history'])

        # Split features and target
        X = dataset.drop(columns=['diabetes'])
        y = dataset['diabetes']

        # Split data for training
        X_train, _, y_train, _ = train_test_split(X, y, test_size=0.3, random_state=42)

        st.markdown("# MANIPAL HOSPITAL")

        st.image("Images/manipal.png")

        st.title("Running the ANN model in MANIPAL HOSPITAL local system ")

        # Train ANN model
        ann_model = train_ann(X_train, y_train)

        # Save model weights in HDF5 format
        ann_model.save_weights("ANN_model.weights.h5")

        # Connect to server and send model weights
        client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        client_socket.connect(('localhost', 1111))
        with open("ANN_model.weights.h5", "rb") as f:
            model_weights_data = f.read()
        client_socket.send(model_weights_data)
        client_socket.close()
        st.write("Hospital 1 ANN Model weights sent successfully!")
    except Exception as e:
        st.write("An error occurred:", e)

if __name__ == "__main__":
    main()
