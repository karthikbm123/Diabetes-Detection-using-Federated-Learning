import pandas as pd
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense
import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import confusion_matrix, accuracy_score
import pandas as pd
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import SimpleRNN, Dense

def load_model(weights_path):
    # Create the same architecture as the trained model
    model = Sequential([
        Dense(64, activation='relu', input_shape=(8,)),
        Dense(64, activation='relu'),
        Dense(1, activation='sigmoid')
    ])
    # Load the trained weights
    model.load_weights(weights_path)
    return model

# def load_model(weights_path):
#     # Create the same architecture as the trained model
#     model = Sequential([
#         SimpleRNN(64, input_shape=(X_test.shape[1], 1)),
#         Dense(64, activation='relu'),
#         Dense(1, activation='sigmoid')
#     ])
#     # Load the trained weights
#     model.load_weights(weights_path)
#     return model

def predict(model, X_test):
    # Make predictions on the test data
    y_pred_prob = model.predict(X_test)

    # Convert predicted probabilities to binary predictions
    y_pred = (y_pred_prob > 0.5).astype(int)

    return y_pred

X_test = pd.read_csv("hospital_data/X_smote.csv")
def main():
    try:
        # Load the testing data
        X_test = pd.read_csv("hospital_data/X_smote.csv")
        y_test = pd.read_csv("hospital_data/y_smote.csv")

        # Load the trained model
        model = load_model("ANN_model.weights.h5")

        # Predict using the loaded model
        predictions = predict(model, X_test)

        # Print the predictions
        print("Predictions:", predictions)

        # Calculate accuracy
        accuracy = accuracy_score(y_test, predictions)
        print("Accuracy:", accuracy)

        # Plot confusion matrix
        cm = confusion_matrix(y_test, predictions)
        print("Confusion Matrix:")
        print(cm)

    except Exception as e:
        print("An error occurred:", e)

if __name__ == "__main__":
    main()
