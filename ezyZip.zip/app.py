import streamlit as st
import pandas as pd
from predict import load_model, predict
import streamlit as st
import subprocess

processes = []

def run_script(script_name, output_placeholder):
    output_placeholder.subheader(f"Output of {script_name}:")
    process = subprocess.Popen(["python", f"{script_name}.py"], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    processes.append(process)

    while True:
        output = process.stdout.readline()
        if output == "" and process.poll() is not None:
            break
        if output:
            output_placeholder.code(output.strip())

def terminate_processes():
    for process in processes:
        process.terminate()
# Load the trained model
model = load_model("Rnn_model.weights.h5")

def main():
    # Set the title of the app
    st.title("Secure Federated Learning for Decentralized AI Systems")
    st.image('Images/coverpage.png')

    import streamlit as st
    import subprocess

    def run_script(script_name):
        subprocess.Popen(["python", f"{script_name}.py"])

    def main():
        # Set the title of the app
        st.title("SECURE FEDERATED LEARNING FOR DECENTRALIZED AI SYSTEMS")
        st.image('Images/coverpage.png')
        st.title("DIABETES PREDICTION")

        st.header("Global Server Model")
        st.markdown("Click the button below to start the global server model.")
        if st.button("Start Global Server Model", key="start_global"):
            subprocess.Popen(["streamlit", "run", "globalmodel.py"])

        st.header("Data Collection from Hospitals")
        st.markdown("Click the buttons below to fetch data from each hospital.")
        if st.button("Fetch Data from Hospital 1", key="fetch_hospital_1"):
            subprocess.Popen(["streamlit", "run", "hospital1.py"])

        if st.button("Fetch Data from Hospital 2", key="fetch_hospital_2"):
            subprocess.Popen(["streamlit", "run", "hospital2.py"])

        if st.button("Fetch Data from Hospital 3", key="fetch_hospital_3"):
            subprocess.Popen(["streamlit", "run", "hospital3.py"])


    if st.button("Predict the risk of Disease"):
        # Create input fields for user to enter data
        st.subheader("Enter Patient Details:")
        gender = st.radio("Gender", ["Male", "Female"])
        age = st.number_input("Age", min_value=0, max_value=100, step=1)
        hypertension = st.selectbox("Hypertension", [0, 1])
        heart_disease = st.selectbox("Heart Disease", [0, 1])
        smoking_history = st.selectbox("Smoking History", ["Unknown", "Never", "Formerly", "Currently"])
        bmi = st.number_input("BMI", min_value=0.0, max_value=100.0, step=0.1)
        hba1c_level = st.number_input("HbA1c Level", min_value=0.0, max_value=15.0, step=0.1)
        blood_glucose_level = st.number_input("Blood Glucose Level", min_value=0, max_value=500, step=1)

        # Map categorical values to numeric codes
        smoking_history_mapping = {"Unknown": 0, "Never": 1, "Formerly": 2, "Currently": 3}
        gender_mapping = {"Male": 0, "Female": 1}
        smoking_history = smoking_history_mapping[smoking_history]
        gender = gender_mapping[gender]

        # Prepare input data as a DataFrame
        input_data = pd.DataFrame({
            "gender": [gender],
            "age": [age],
            "hypertension": [hypertension],
            "heart_disease": [heart_disease],
            "smoking_history": [smoking_history],
            "bmi": [bmi],
            "HbA1c_level": [hba1c_level],
            "blood_glucose_level": [blood_glucose_level]
        })

        # Make prediction
        if st.button("Predict"):
            # Make prediction using the loaded model
            prediction = predict(model, input_data)

            # Display prediction result
            if prediction[0] == 1:
                st.error("The patient is predicted to have diabetes.")
            else:
                st.success("The patient is predicted not to have diabetes.")


if __name__ == "__main__":
    main()
