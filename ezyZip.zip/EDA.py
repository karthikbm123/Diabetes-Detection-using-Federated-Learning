import warnings
import pandas as pd
from sklearn.preprocessing import LabelEncoder
from imblearn.over_sampling import SMOTE
import seaborn as sns
import matplotlib.pyplot as plt

# Ignore future warnings
warnings.simplefilter(action='ignore', category=FutureWarning)

# Step 1: Load the Dataset
dataset = pd.read_csv("diabetes_prediction_dataset.csv")

# Step 2: Handle Categorical Variables
# Encode categorical variables
encoder = LabelEncoder()
dataset['gender'] = encoder.fit_transform(dataset['gender'])
dataset['smoking_history'] = encoder.fit_transform(dataset['smoking_history'])

# Step 3: Split Features and Target
X = dataset.drop(columns=['diabetes'])
y = dataset['diabetes']

# Step 3: Perform EDA
# Check the first few rows
print(dataset.head())

# Check data types
print(dataset.dtypes)

# Check for missing values
print(dataset.isnull().sum())

# Summary statistics
print(dataset.describe())

# Visualize univariate distributions
for column in dataset.columns:
    sns.histplot(dataset[column], kde=True)
    plt.title(f"Distribution of {column}")
    # plt.show()

# Visualize bivariate relationships
sns.pairplot(dataset)
plt.show()

# Visualize correlation matrix
sns.heatmap(dataset.corr(), annot=True, cmap="coolwarm")
plt.title("Correlation Matrix")
plt.show()

sns.countplot(x=y)
plt.title("Target Class Distribution Before SMOTE")
plt.xlabel("Class")
plt.ylabel("Count")
plt.show()

import matplotlib.pyplot as plt

# Define model names and their accuracies
models = ['RNN', 'ANN', 'LSTM']
accuracies = [89.00, 89.99, 89.08]

# Plotting the bar graph
plt.figure(figsize=(8, 6))
plt.bar(models, accuracies, color=['blue', 'green', 'red'])

# Adding labels and title
plt.xlabel('Model')
plt.ylabel('Testing Accuracy (%)')
plt.title('Accuracy of Different Models')
plt.ylim(0, 100)

# Adding percentages above bars
for i, acc in enumerate(accuracies):
    plt.text(i, acc + 1, f'{acc:.2f}%', ha='center')

# Display the plot
plt.show()


# Step 4: Perform SMOTE
smote = SMOTE(random_state=42)
X_smote, y_smote = smote.fit_resample(X, y)

# Step 5: Count plot after SMOTE
sns.countplot(x=y_smote)
plt.title("Target Class Distribution after SMOTE")
plt.xlabel("Class")
plt.ylabel("Count")
plt.show()

print(X_smote.shape)
print(y_smote.shape)

# Convert resampled data to integer
X_smote_df = X_smote.astype(int)
y_smote_df = y_smote.astype(int)

# Save resampled data to directory
resampled_data_dir = "hospital_data/"
X_smote_df.to_csv(resampled_data_dir + "X_smote.csv", index=False)
y_smote_df.to_csv(resampled_data_dir + "y_smote.csv", index=False)

print("Resampled data saved successfully.")

# Concatenate X_smote_df and y_smote_df
Xy_smote_df = pd.concat([X_smote_df, y_smote_df], axis=1)

# Save concatenated DataFrame to CSV
concatenated_file_path = "hospital_data/Full_smote_Diabetes_df.csv"
Xy_smote_df.to_csv(concatenated_file_path, index=False)

print("Concatenated SMOTE DataFrame saved successfully.")
