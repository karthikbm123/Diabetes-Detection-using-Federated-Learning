import os
import pandas as pd
from sklearn.model_selection import train_test_split

# Read the dataset
dataset = pd.read_csv("hospital_data/Full_smote_Diabetes_df.csv")

# Create the directory if it doesn't exist
if not os.path.exists("hospital_data"):
    os.makedirs("hospital_data")

# Randomly split the dataset into three parts, each containing 30% of the data
hospital1_data, remaining_data = train_test_split(dataset, test_size=0.7, random_state=42)
hospital2_data, hospital3_data = train_test_split(remaining_data, test_size=0.5, random_state=42)

# Save each split as a CSV file in the "hospital_data" directory
hospital1_data.to_csv("hospital_data/hospital1.csv", index=False)
hospital2_data.to_csv("hospital_data/hospital2.csv", index=False)
hospital3_data.to_csv("hospital_data/hospital3.csv", index=False)

print("Data split and saved successfully.")



import pandas as pd
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split

# Read the dataset
dataset = pd.read_csv("hospital_data/Full_smote_Diabetes_df.csv")

# Encode categorical variables
encoder = LabelEncoder()
dataset['gender'] = encoder.fit_transform(dataset['gender'])
dataset['smoking_history'] = encoder.fit_transform(dataset['smoking_history'])

# Split features and target
X = dataset.drop(columns=['diabetes']).values
y = dataset['diabetes'].values.reshape(-1, 1)

# Split data for training and testing
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

# Save X_test.csv
pd.DataFrame(X_test, columns=dataset.columns[:-1]).to_csv("X_test.csv", index=False)

# Save y_test.csv
pd.DataFrame(y_test, columns=['diabetes']).to_csv("y_test.csv", index=False)

print("X_test.csv and y_test.csv saved successfully.")


