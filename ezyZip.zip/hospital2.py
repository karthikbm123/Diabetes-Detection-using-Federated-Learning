import socket
import pandas as pd
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense
import streamlit as st

from tqdm import tqdm


import matplotlib.pyplot as plt

def train_LSTM(X_train, y_train):
    LSTM_model = Sequential([
        LSTM(64, input_shape=(X_train.shape[1], 1)),
        Dense(64, activation='relu'),
        Dense(1, activation='sigmoid')
    ])
    LSTM_model.compile(optimizer='adam',
                      loss='binary_crossentropy',
                      metrics=['accuracy'])

    epochs = 10
    accuracy_list = []
    loss_list = []
    for epoch in range(epochs):
        st.text(f"Epoch {epoch+1}/{epochs}")
        history = LSTM_model.fit(X_train, y_train, epochs=1, batch_size=32, verbose=1)
        train_loss = history.history['loss'][0]
        train_accuracy = history.history['accuracy'][0]
        st.text(f"Training Loss: {train_loss}, Accuracy: {train_accuracy}")
        accuracy_list.append(train_accuracy)
        loss_list.append(train_loss)

    st.write("Training completed! LSTM Model Weights successfully Transferred to global model")

    # Display training accuracy graph
    plt.plot(range(1, epochs+1), accuracy_list, marker='o', label='Accuracy')
    plt.plot(range(1, epochs+1), loss_list, marker='o', label='Loss')
    plt.xlabel('Epoch')
    plt.title('Training Accuracy and Loss')
    plt.legend()
    st.pyplot(plt)

    return LSTM_model



def main():
    st.set_page_config(page_title="Hospital 2", layout="wide")
    try:
        # Read dataset
        dataset = pd.read_csv("hospital_data/hospital2.csv")

        # Encode categorical variables
        encoder = LabelEncoder()
        dataset['gender'] = encoder.fit_transform(dataset['gender'])
        dataset['smoking_history'] = encoder.fit_transform(dataset['smoking_history'])

        # Split features and target
        X = dataset.drop(columns=['diabetes']).values
        y = dataset['diabetes'].values.reshape(-1, 1)

        # Split data for training
        X_train, _, y_train, _ = train_test_split(X, y, test_size=0.2, random_state=42)

        # Reshape X_train for LSTM input
        X_train = X_train.reshape((X_train.shape[0], X_train.shape[1], 1))


        st.markdown("FORTIS HOSPITAL")

        st.image("Images/fortis.png")

        st.title("Running the LSTM model in FORTIS HOSPITAL local system ")

        # Train RNN model
        LSTM_model = train_LSTM(X_train, y_train)

        # Save model weights in HDF5 format
        LSTM_model.save_weights("LSTM_model.weights.h5")

        # Connect to server and send model weights
        client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        client_socket.connect(('localhost', 1111))
        with open("LSTM_model.weights.h5", "rb") as f:
            model_weights_data = f.read()
        client_socket.send(model_weights_data)
        client_socket.close()
        st.write("Hospital 2 LSTM Model weights sent successfully!")
    except Exception as e:
        st.write("An error occurred:", e)

if __name__ == "__main__":
    main()
